# Referencias para los modelos de la preparación

Imágenes individuales generadas con la herramienta integrada ImageGen el 7 de septiembre de 2026. Prompts completos en `prompts.json`.

- `taza.png`: taza vacía de cerámica marfil, con asa y boca abierta.
- `tetera.png`: tetera de acero satinado con cuello de cisne.
- `cuchara.png`: cuchara dosificadora vacía de acero satinado.

Cada archivo contiene un único objeto sobre fondo neutro. Se entregan como referencias visuales para crear los modelos; no son planos ni geometría 3D. Los futuros modelos podrán incorporarse a la preparación de café cuando estén disponibles. El logo se puede aplicar en la web como textura independiente.
